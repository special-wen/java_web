'use strict'

let sate = document.getElementsByClassName('sate');

sate.onclick = function () {
    alert('aa');
}
